from django.contrib import admin
from .models import Supercomputadora

admin.site.register(Supercomputadora)
